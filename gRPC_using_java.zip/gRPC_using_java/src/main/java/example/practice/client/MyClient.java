package example.practice.client;

import com.proto.greet.*;
import io.grpc.*;
import io.grpc.stub.StreamObserver;

import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MyClient {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("Hello I am a gRPC Client");

        runClient();
    }

    private static void runClient() throws InterruptedException {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost",50051)
                .usePlaintext()
                .build();

        //doUnaryCall(channel);
        //doServerStreamingCall(channel);
        //doClientStreamingCall(channel);
        //doBiDiStreamingCall (channel);
        doUnaryCallWithDeadline (channel);

        System.out.println("Shutting down channel");
        channel.shutdown();
    }

    private static void doUnaryCallWithDeadline(ManagedChannel channel) {
        GreetServiceGrpc.GreetServiceBlockingStub blockingStub = GreetServiceGrpc.newBlockingStub(channel);

        // First call with 3000 ms deadline.
        try {
            System.out.println("Sending the request with a deadline of 3000 ms.");
            GreetWithDeadlineResponse greetWithDeadlineResponse = blockingStub.withDeadline(Deadline.after(3000, TimeUnit.MILLISECONDS)).greetWithDeadline(
                    GreetWithDeadlineRequest.newBuilder()
                            .setGreeting(Greet.newBuilder()
                                    .setFirstName("Mitali").build()).build());
            System.out.println(greetWithDeadlineResponse.getResult());
        }catch (StatusRuntimeException e){
            if(e.getStatus()== Status.DEADLINE_EXCEEDED) {
                System.out.println("Deadline has exceeded, we don't want the response. ");
            }
            else {
               e.printStackTrace();
            }
        }

        // Second call with 100 ms deadline.
        try {
            System.out.println("Sending the request with a deadline of 100 ms.");
            GreetWithDeadlineResponse greetWithDeadlineResponse = blockingStub.withDeadline(Deadline.after(100, TimeUnit.MILLISECONDS)).greetWithDeadline(
                    GreetWithDeadlineRequest.newBuilder()
                            .setGreeting(Greet.newBuilder()
                                    .setFirstName("Mitali").build()).build());
            System.out.println(greetWithDeadlineResponse.getResult());
        }catch (StatusRuntimeException e){
            if(e.getStatus()== Status.DEADLINE_EXCEEDED) {
                System.out.println("Deadline has exceeded, we don't want the response. ");
            }
            else {
                e.printStackTrace();
            }
        }
    }

    private static void doBiDiStreamingCall(ManagedChannel channel) {
        System.out.println("Creating a stub");

        GreetServiceGrpc.GreetServiceStub asyncClient = GreetServiceGrpc.newStub(channel);

        CountDownLatch countDownLatch = new CountDownLatch(1);

        StreamObserver<GreetEveryoneRequest> requestStreamObserver = asyncClient.greetEveryone(new StreamObserver<GreetEveryoneResponse>() {
            @Override
            public void onNext(GreetEveryoneResponse value) {
               System.out.println(value.getResult());
            }

            @Override
            public void onError(Throwable t) {
               countDownLatch.countDown();
            }

            @Override
            public void onCompleted() {
              System.out.println("Server is done sending data...");
              countDownLatch.countDown();
            }
        });
        Arrays.asList("Mitali","Rajat","Lokesh","Divya").forEach(name ->
                                                                    {
                                                                        System.out.println("Sending Name "+ name);
                                                                        requestStreamObserver.onNext(GreetEveryoneRequest
                                                                        .newBuilder()
                                                                        .setGreeting(Greet.newBuilder()
                                                                        .setFirstName(name)
                                                                         .build())
                                                                        .build());
                                                                        try {
                                                                            Thread.sleep(1000);
                                                                        } catch (InterruptedException e) {
                                                                            e.printStackTrace();
                                                                        }
                                                                    });
        requestStreamObserver.onCompleted();
        try {
            countDownLatch.await(3L,TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static void doClientStreamingCall(ManagedChannel channel) throws InterruptedException {
        System.out.println("Creating a stub");

       GreetServiceGrpc.GreetServiceStub asyncClient = GreetServiceGrpc.newStub(channel);

       CountDownLatch countDownLatch = new CountDownLatch(1);

       StreamObserver<LongGreetRequest> requestStreamObserver= asyncClient.longGreet(new StreamObserver<LongGreetResponse>() {
           @Override
           public void onNext(LongGreetResponse value) {
               // We get a response from the server.
               System.out.println("Recieved a response from the server.");
               System.out.println(value.getResult());
               // onNext will be called exactly once, since server is not streaming.
           }

           @Override
           public void onError(Throwable t) {
               // We get a error response from the server.
           }

           @Override
           public void onCompleted() {
             // The server is done sending us data.
             // onCompleted will be called right after onNext().
               System.out.println("Server has completed sending us something.");
               countDownLatch.countDown();
           }
       });

        // Streaming message #1
        System.out.println("Sending Message1");
        requestStreamObserver.onNext(LongGreetRequest.newBuilder()
                                                    .setGreeting(Greet.newBuilder()
                                                                      .setFirstName("Mitali").build()).build());
        // Streaming message #2
        System.out.println("Sending Message2");
        requestStreamObserver.onNext(LongGreetRequest.newBuilder()
                .setGreeting(Greet.newBuilder()
                        .setFirstName("Lokesh").build()).build());

      // Streaming message #3
        System.out.println("Sending Message3");
        requestStreamObserver.onNext(LongGreetRequest.newBuilder()
                .setGreeting(Greet.newBuilder()
                        .setFirstName("Rajat").build()).build());

      // We tell the server that client is done sending the data.
      requestStreamObserver.onCompleted();

      countDownLatch.await(3L, TimeUnit.SECONDS);
    }

    private static void doServerStreamingCall(ManagedChannel channel) {
        System.out.println("Creating a stub");

        GreetServiceGrpc.GreetServiceBlockingStub syncGreetStub = GreetServiceGrpc.newBlockingStub(channel);

        // Server Streaming.
        // We prepare the request.
        GreetManyTimesRequest greetManyTimesRequest = GreetManyTimesRequest.newBuilder().setGreeting(
                Greet.newBuilder()
                        .setFirstName("Lokesh"))
                .build();

        // We streams the response in a blocking manner.
        syncGreetStub.greetManyTimes(greetManyTimesRequest)
                .forEachRemaining(GreetManyTimesResponse -> {
                    System.out.println(GreetManyTimesResponse.getResult());
                }); ;
    }

    private static void doUnaryCall(ManagedChannel channel) {
        System.out.println("Creating a stub");

        GreetServiceGrpc.GreetServiceBlockingStub syncGreetStub = GreetServiceGrpc.newBlockingStub(channel);

        // Unary.
        // Created a protocol buffer for GreetRequest.
        GreetRequest greetRequest = GreetRequest.newBuilder()
                .setGreeting(Greet.newBuilder()
                        .setFirstName("Mitali")
                        .setLastName("Aggarwal")
                        .build())
                .build();

        // Call the rpc and get back a GreetResponse (protocol buffers)
        GreetResponse greetResponse = syncGreetStub.greet(greetRequest);

        System.out.println(greetResponse.getResult());
    }
}
