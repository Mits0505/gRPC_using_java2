package example.practice.calculator.server;

import com.proto.calculator.CalculatorServiceGrpc;
import com.proto.calculator.SqaureRootResponse;
import com.proto.calculator.SquareRootRequest;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;

public class CalculatorServiceImpl extends CalculatorServiceGrpc.CalculatorServiceImplBase {
    @Override
    public void squareRoot(SquareRootRequest request, StreamObserver<SqaureRootResponse> responseObserver) {
        int number = request.getNumber();
        if(number > 0) {
            double squareRoot = Math.sqrt(number);
            responseObserver.onNext(SqaureRootResponse.newBuilder()
                    .setSquareRoot(squareRoot).build());
        }else{
            // We construct the exception.
            responseObserver.onError(
                    Status.INVALID_ARGUMENT
                          .withDescription("The number being sent is not positive.")
                            .augmentDescription("Number sent: "+number)
                          .asRuntimeException()
            );
        }
    }
}
